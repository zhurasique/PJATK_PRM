package com.example.cookieclicker;

import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.media.Image;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.security.Key;
import java.text.SimpleDateFormat;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private TextView tvPoints;
    private TextView timer;
    private TextView earning;
    private int points;
    private int tmpTimer;
    private int cpc = 1;
    private int time = 10;
    private int cps = 10;
    private SimpleDateFormat sdf = new SimpleDateFormat("m:ss");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_activity);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event){
        if(keyCode == KeyEvent.KEYCODE_BACK){
            showCookieFragment();
            tvPoints = findViewById(R.id.tvPoints);
            tvPoints.setText("Cookies: " + points);
            timer = findViewById(R.id.timer);
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public void onPause(){
        super.onPause();
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.imgCookie) {
            Animation a = AnimationUtils.loadAnimation(this, R.anim.cookie_animation);
            a.setAnimationListener(new MyAnimationListiner() {
                @Override
                public void onAnimationEnd(Animation animation) {
                    cookieClick();
                }
            });
            v.startAnimation(a);
        } else if (v.getId() == R.id.btnShop) {
            showShop();
        } else if (v.getId() == R.id.newGame) {
            showGame();
            tmpTimer = 0;
            points = 0;
            CookieCounter au = new CookieCounter();
            timer = findViewById(R.id.timer);
            tvPoints = findViewById(R.id.tvPoints);
        } else if (v.getId() == R.id.exitGame){
            finish();
        } else if(v.getId() == R.id.imgItem1 || v.getId() == R.id.tvDescription1){
            if (points >= 30) {
                cpc += 10;
                updatePoints(350);
            } else {
                (new AlertDialog.Builder(MainActivity.this)).setMessage("Not enough cookies! (You need 350 cookies)")
                        .show();
            }
        }else if(v.getId() == R.id.imgItem2 || v.getId() == R.id.tvDescription2){
            if (points >= 800) {
                cpc += 20;
                updatePoints(800);
            } else {
                (new AlertDialog.Builder(MainActivity.this)).setMessage("Not enough cookies! (You need 800 cookies)")
                        .show();
            }
        }else if(v.getId() == R.id.imgItem3 || v.getId() == R.id.tvDescription3){
            if (points >=2000) {
                updatePoints(2000);
            } else {
                (new AlertDialog.Builder(MainActivity.this)).setMessage("Not enough cookies! (You need 2000 cookies)")
                        .show();
            }
        }else if(v.getId() == R.id.imgItem4 || v.getId() == R.id.tvDescription4){
            if (points >= 3000) {
                updatePoints(3000);
            } else {
                (new AlertDialog.Builder(MainActivity.this)).setMessage("Not enough cookies! (You need 3000 cookies)")
                        .show();
            }
        }else if(v.getId() == R.id.imgItem5 || v.getId() == R.id.tvDescription5){
            if (points >= 1800) {
                AutoClicker au = new AutoClicker();
                updatePoints(1800);
            } else {
                (new AlertDialog.Builder(MainActivity.this)).setMessage("Not enough cookies! (You need 1800 cookies)")
                        .show();
            }
        }
    }

    private void showCookieFragment(){
        ViewGroup container = findViewById(R.id.conteiner);
        container.removeAllViews();
        container.addView(getLayoutInflater().inflate(R.layout.activity_main, null));
    }

    private void cookieClick() {
        points += cpc;
        tvPoints.setText("Cookies: " + Integer.toString(points));
        showToast(R.string.clicked);
    }

    private void showToast(int stringID) {
        Toast toast = new Toast(this);
        toast.setGravity(Gravity.CENTER, 0, 0);
        toast.setDuration(Toast.LENGTH_SHORT);
        TextView textView = new TextView(this);
        textView.setText(stringID);
        textView.setTextSize(40f);
        textView.setTextColor(Color.BLACK);
        toast.setView(textView);
        toast.show();
    }

    private void update(){
        tmpTimer += time/10;
        timer.setText("Time: " + sdf.format(tmpTimer));
        if(tmpTimer == 180000) {
            showFinishMenu();
            earning = findViewById(R.id.earning);
            earning.setText("You earn: " + points + " cookies.");
        }
    }

    private void updateCookies(){
        points += cps/10;
        tvPoints.setText("Cookies: " + points);
    }

    private void updatePoints(int i){
        points -= i;
    }

    private void showShop(){
        ViewGroup container = findViewById(R.id.conteiner);
        container.removeAllViews();
        container.addView(getLayoutInflater().inflate(R.layout.shop_activity, null));
    }

    private void showGame(){
        ViewGroup container = findViewById(R.id.start);
        container.removeAllViews();
        container.addView(getLayoutInflater().inflate(R.layout.activity_main, null));
    }

    private void showFinishMenu(){
        ViewGroup container = findViewById(R.id.conteiner);
        container.removeAllViews();
        container.addView(getLayoutInflater().inflate(R.layout.finish_menu, null));
    }

    public class CookieCounter{
        private Timer timer;

        public CookieCounter(){
            timer = new Timer();
            timer.scheduleAtFixedRate(new TimerTask() {
                @Override
                public void run() {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            update();
                        }
                    });
                }
                }, 100, 1);
        }
    }

    public class AutoClicker{
        private Timer timer;

        public AutoClicker(){
            timer = new Timer();
            timer.scheduleAtFixedRate(new TimerTask() {
                @Override
                public void run() {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            updateCookies();
                        }
                    });
                }
            }, 100, 50);
        }
    }
}
